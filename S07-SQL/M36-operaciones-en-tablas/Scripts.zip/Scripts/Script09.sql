USE AdventureWorks2022;
GO

TRUNCATE TABLE Prueba;

DROP TABLE Prueba;
