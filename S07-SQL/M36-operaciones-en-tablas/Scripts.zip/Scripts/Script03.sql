USE AdventureWorks2022;
GO

EXEC sp_rename 'dbo.Ventas', 'Ordenes';
